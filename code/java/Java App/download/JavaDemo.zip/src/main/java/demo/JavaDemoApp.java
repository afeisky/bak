package demo;

import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.TabFolder;
import org.eclipse.swt.widgets.TabItem;

import demo.tabs.NetTab;
import demo.tabs.ThreadTab;

public class JavaDemoApp {
	private Display mDisplay;
	private Shell mShell;
	TabFolder	mTabFolder;
	TabBase[] mTabs;
	
	public JavaDemoApp(Display display, Shell shell){
		mDisplay = display;
		mShell = shell;
		
	}
	
	private TabBase[] createTabs() {
		return new TabBase[] {
			//new IOTab(mTabFolder, SWT.NONE),
			//new LanguageTab(mTabFolder, SWT.NONE),
			//new NetTab(mTabFolder, SWT.NONE),
			new ThreadTab(mTabFolder, SWT.NONE),
		};
	}
	
	public void Run(){
		
		mTabFolder = new TabFolder(mShell, SWT.None);
		mTabs = createTabs();
		System.out.println("Enter JavaDemoApp.run: mtabs = " + mTabs.length);

		for(int i = 0; i < mTabs.length; i++){
			TabItem item = new TabItem(mTabFolder, SWT.NONE);
			item.setText(mTabs[i].getTabText());
			item.setControl(mTabs[i]);
			item.setData(mTabs[i]);
		}
		
		System.out.println("Before JavaDemoApp.open");
		mShell.open();
		mShell.layout();
		while (!mShell.isDisposed()) {
			if (!mDisplay.readAndDispatch()) {
				mDisplay.sleep();
			}
		}
	}
	

	private void dispose() {
		System.out.println("JavaDemoApp dispose");
		if (mTabs != null) {
			for(int i = 0; i < mTabs.length; i++){
				mTabs[i].dispose();
			}
			mTabs = null;
		}
	}
	
	public static void main(String[] args) {
		System.out.println("Enter JavaDemo App");
		Display display = new Display(); //Display.getDefault();
		Shell shell = new Shell();
		shell.setLayout(new FillLayout());
		//shell.pack();
		//shell.setSize(450, 300);
		shell.setText("SWT Application");
		
		JavaDemoApp instance = new JavaDemoApp(display, shell);
		instance.Run();
		instance.dispose();
	}



}
