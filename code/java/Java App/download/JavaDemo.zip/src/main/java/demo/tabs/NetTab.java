package demo.tabs;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.JarURLConnection;
import java.net.MalformedURLException;
import java.net.NetworkInterface;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketAddress;
import java.net.SocketException;
import java.net.URI;
import java.net.URL;
import java.net.UnknownHostException;
import java.nio.channels.DatagramChannel;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Enumeration;

import javax.net.ssl.SSLServerSocket;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Label;

import demo.TabBase;

public class NetTab extends TabBase {
	/* (non-Javadoc)
	 * @see demo.TabBase#dispose()
	 */
	@Override
	public void dispose() {
		super.dispose();
	}

	public NetTab(Composite parent, int style) {
		super(parent, style);

	}

	@Override
	protected void checkSubclass() {
		// Disable the check that prevents subclassing of SWT components
	}

	protected void createServerSocketControls() {
		Group grpSrvSocket = new Group(this, SWT.NONE);
		grpSrvSocket.setText("ServerSocket");
		grpSrvSocket.setLayout(new GridLayout(4, false));
		
		final Button btnSocketReuse = new Button(grpSrvSocket, SWT.CHECK);
		btnSocketReuse.setText("reuse");
		
		Button btnServerCreate = new Button(grpSrvSocket, SWT.NONE);
		btnServerCreate.setText("Create");

		Button btnServerListen = new Button(grpSrvSocket, SWT.NONE);
		btnServerListen.setText("listen");
		
		Button btnServerClose = new Button(grpSrvSocket, SWT.NONE);
		btnServerClose.setText("Close");
	}
	
	protected void createClientSocketControls() {
		Group grpClientSocket = new Group(this, SWT.NONE);
		grpClientSocket.setText("ClientSocket");
		grpClientSocket.setLayout(new GridLayout(3, false));
		Button btnClientConnect = new Button(grpClientSocket, SWT.NONE);
		btnClientConnect.setText("Connect");
		
		Button btnClientSend = new Button(grpClientSocket, SWT.NONE);
		btnClientSend.setText("Send");
		
		Button btnClientClose = new Button(grpClientSocket, SWT.NONE);
		btnClientClose.setText("Close");
	}
	
	protected void createHttpControls() {
		Group grpHttp = new Group(this, SWT.NONE);
		grpHttp.setText("HTTP");
		grpHttp.setLayout(new GridLayout(1, false));
		Button btnHttpGet = new Button(grpHttp, SWT.NONE);
		btnHttpGet.setText("Get");
	}

	
	protected void createUtilsControls() {
		Group grpUtils = new Group(this, SWT.NONE);
		grpUtils.setText("Utils");
		grpUtils.setLayout(new GridLayout(4, false));
		
		Button btnInetaddress = new Button(grpUtils, SWT.NONE);
		btnInetaddress.setText("InetAddress");
		Button btnEncoder = new Button(grpUtils, SWT.NONE);
		btnEncoder.setText("URLEncoder");
		Button btnDecoder = new Button(grpUtils, SWT.NONE);
		btnDecoder.setText("URLDecoder");
		
		Button btnNetworkInterface = new Button(grpUtils, SWT.NONE);
		btnNetworkInterface.setText("NetworkInterface");
	}

	@Override
	protected void createDemoControls() {
		createServerSocketControls();
		createClientSocketControls();
		createHttpControls();
		createUtilsControls();
	}

	@Override
	public String getTabText() {
		return "Net";
	}
}
