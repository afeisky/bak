package demo.tabs;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.concurrent.Callable;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.locks.Condition;

import javax.security.sasl.AuthorizeCallback;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.internal.win32.LOGBRUSH;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.ProgressBar;

import demo.TabBase;
import util.FThread;

import org.eclipse.swt.widgets.Label;

public class ThreadTab extends TabBase {
	Button btnThreadStart, btnThreadPause, btnThreadResume, btnThreadStop;
	Button btnThreadPoolStart, btnThreadPoolAddjob, btnThreadPoolStop;

	FThread	mThread;
	ExecutorService mPoolExecutor;
	ArrayList<Future<String>>	mPoolResult = new ArrayList<Future<String>>();
	
	class ThreadHandleDemo extends FThread{
		Display mDisplay;

		ThreadHandleDemo(Display display) {
			this.mDisplay = display;
		}

		private boolean isRunning = true;

		public void run() {
			log("Enter ThreadHandleDemo.run");
//			Thread curThread = Thread.currentThread();
//			while (!curThread.isInterrupted() && isRunning) {
//				log("Thread Run " + Thread.currentThread());
//				// System.out.println("Thread Run " + Thread.currentThread());
//			}
			while (true){ // && isRunning) {
				if (getWaitType() != FThread.ThreadWaitType.twtContinue) {
					break;
				}
				
				// 如果直接在子线程中更新ProgressBar(UI),会抛出 SWTException: Invalid thread access
				// progBarThread.setSelection((progBarThread.getSelection() + 10) % 100);
				mDisplay.asyncExec(new Runnable() {
					public void run() {
						int newValue = (progBarThread.getSelection() + 10);
						if (newValue > 100) {
							newValue = 0;
						}
						log("progressValue=" + newValue);
						progBarThread.setSelection(newValue);
					}
				});

				try {
					Thread.sleep(500);
				} catch (InterruptedException e) {
					isRunning = false;
					e.printStackTrace();
				}
			}
			log("Leave ThreadHandleDemo.run");
		}
	}

	/**
	 * Create the composite.
	 * @param parent
	 * @param style
	 */
	public ThreadTab(Composite parent, int style) {
		super(parent, style);
		System.out.println("ThreadTab constructor");
	}

	@Override
	protected void checkSubclass() {
		// Disable the check that prevents subclassing of SWT components
	}
	
	protected SelectionListener eventThreadHandler = new SelectionAdapter() {
		@Override
		public void widgetSelected(SelectionEvent e) {
			//System.out.println(e);
		}
		
	};
	private ProgressBar progBarThread;

	
	@Override
	protected void createDemoControls() {
		super.createDemoControls();

		createThreadControls();
		createThreadPoolControls();
		createConcurrentControls();
	}

	protected void createThreadPoolControls() {
		Group grpThreadPool = new Group(this, SWT.NONE);
		grpThreadPool.setText("ThreadPool");
		grpThreadPool.setLayout(new GridLayout(3, false));
		btnThreadPoolStart = new Button(grpThreadPool, SWT.NONE);
		btnThreadPoolStart.setText("Start");

		
		btnThreadPoolAddjob = new Button(grpThreadPool, SWT.NONE);
		btnThreadPoolAddjob.setText("AddJob");
		
		btnThreadPoolStop = new Button(grpThreadPool, SWT.NONE);
		btnThreadPoolStop.setText("Stop");
	}

	protected void createThreadControls() {
		/* Add the listeners */
		SelectionListener threadButtonEventHandler = new SelectionAdapter () {
			public void widgetSelected(SelectionEvent event) {
				Button btnClick = (Button) event.widget;
				System.out.println(event);

				if (btnClick == btnThreadStart) {
					mThread = new ThreadHandleDemo(btnClick.getDisplay());
					mThread.start();
				}
				if (btnClick == btnThreadPause) {
					if (mThread != null) {
						mThread.pause();
					}					
				}
				else if(btnClick == btnThreadResume){
					if (mThread != null) {
						mThread.resume();
					}
				}
				else if(btnClick == btnThreadStop){
					System.out.println("Click BtnStop");
					if (mThread != null) {
						mThread.stop();
						mThread.join();
						//mThread.interrupt();
					}
				}
			}
		};
			
		Group grpThread = new Group(this, SWT.NONE);
		grpThread.setText("Thread");
		grpThread.setLayout(new GridLayout(5, false));
		
		btnThreadStart = new Button(grpThread, SWT.NONE);
		btnThreadStart.addSelectionListener(threadButtonEventHandler);
		btnThreadStart.setText("start");
		
		btnThreadPause = new Button(grpThread, SWT.NONE);
		btnThreadPause.setText("pause");
		btnThreadPause.addSelectionListener(threadButtonEventHandler);
		
		btnThreadResume = new Button(grpThread, SWT.NONE);
		btnThreadResume.setText("resume");
		btnThreadResume.addSelectionListener(threadButtonEventHandler);
		
		btnThreadStop = new Button(grpThread, SWT.NONE);
		btnThreadStop.setText("stop");
		
		progBarThread = new ProgressBar(grpThread, SWT.SMOOTH);
		btnThreadStop.addSelectionListener(threadButtonEventHandler);
	}

	private void createConcurrentControls() {
		class MyInteger{
			MyInteger(int val){
				mInt = new Integer(val);
			}
			Integer mInt;
		}
		
		Group grpConcurrent = new Group(this, SWT.NONE);
		grpConcurrent.setText("Concurrent");
		grpConcurrent.setLayout(new GridLayout(1, false));
		
		Button btnCAS;

		btnCAS = new Button(grpConcurrent, SWT.NONE);
		final AtomicInteger	safeInteger = new AtomicInteger(0);
		//final Integer unsafeInteger = new Integer(0);  //Integer 是 不可变类，如果直接使用的话，无法获取结果
		final MyInteger	unsafeInteger = new MyInteger(0);
		final Thread threads[] = new Thread[10];
		
		class IncrementThread implements Runnable{
			AtomicInteger mSafeInteger;
			MyInteger mUnsafeInteger;
			boolean mbLock;
			
			/**
			 * @param safeInteger
			 * @param unsafeInteger
			 * @param bLock 如果传入true,则在计算时会锁定 mUnsafeInteger, 使其线程安全的进行递增；
			 *              否则可以查看到 ++操作在多线程计算时的非原子性影响
			 */
			IncrementThread(AtomicInteger safeInteger, MyInteger unsafeInteger, boolean bLock){
				mSafeInteger = safeInteger;
				mUnsafeInteger = unsafeInteger;
				mbLock = bLock;	
			}
			@Override
			public void run() {
				for(int j = 0; j < 100000; j++){
					mSafeInteger.incrementAndGet();
					if (mbLock) {
						synchronized (mUnsafeInteger) {
							mUnsafeInteger.mInt++;
						}
					}
					else{
						mUnsafeInteger.mInt++;
					}
					
				}
			}
		};
		
		btnCAS.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent event) {
				safeInteger.set(0);
				unsafeInteger.mInt = 0;
				long startTime = System.currentTimeMillis();
				for(int i = 0; i < 10; i++){
					threads[i] = new Thread(new IncrementThread(safeInteger, unsafeInteger, false)); //TODO:改成true可以看到unsafeInteger也正确
					threads[i].start();
				}
				for (Thread thread : threads) {
					try {
						thread.join();
					} catch (InterruptedException e1) {
						log(e1.toString());
					}
				}
				long endTime = System.currentTimeMillis();
				log("After 10* 100000, safeInteger=" + safeInteger.get() + "; unsafeIneger=" + unsafeInteger.mInt 
						+ ", Elaspe:" + (endTime - startTime));
			}
		});
		btnCAS.setText("CAS");

	}
	@Override
	public String getTabText() {
		return "Thread";
	}

}
