package demo;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.ControlAdapter;
import org.eclipse.swt.events.ControlEvent;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.graphics.Rectangle;
import org.eclipse.swt.internal.gdip.Rect;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Sash;
import org.eclipse.swt.widgets.Text;

public class TabBase extends Composite {
	Display mDisplay;
	protected Text txtLog;
	protected Button btnWithTime, btnWithThreadId;
	protected Group mGrpDemoControls;
	protected Group mGrpLogControls;
	//protected Sash mSashLog;
	
	/**
	 * Create the composite.
	 * @param parent
	 * @param style
	 */
	public TabBase(Composite parent, int style) {
		super(parent, style);
		setTouchEnabled(true);
		mDisplay = parent.getDisplay();
		
		System.out.println("TabBase constructor");
		setLayout(new GridLayout(1, false));
//		FillLayout layout = new FillLayout();
//		setLayout(layout);
//		mSashLog = new Sash(this,  SWT.HORIZONTAL | SWT.SMOOTH);
//		this.addControlListener(new ControlAdapter(){
//
//			@Override
//			public void controlResized(ControlEvent e) {
//				resize();
//				super.controlResized(e);
//			}
//		});
		createDemoControls();
		createLogControls();
	}

//	protected void resize() {
//		Rectangle rectClient = getBounds();
//		Rectangle rectSash = mSashLog.getBounds();
//	}

	protected void createLogControls() {
		mGrpLogControls = new Group(this, SWT.BORDER | SWT.SHADOW_OUT);
		mGrpLogControls.setLayout(new GridLayout(3, false));
		mGrpLogControls.setLayoutData(new GridData(SWT.FILL, SWT.BOTTOM, true, true, 1, 1));
		mGrpLogControls.setText("log");
	
		txtLog = new Text(mGrpLogControls, SWT.BORDER | SWT.READ_ONLY | SWT.H_SCROLL | SWT.V_SCROLL | SWT.CANCEL | SWT.MULTI);
		GridData gd_txtLog = new GridData(SWT.FILL, SWT.CENTER, true, true, 3, 1);
		gd_txtLog.minimumHeight = 150;
		txtLog.setLayoutData(gd_txtLog);
		
		btnWithTime = new Button(mGrpLogControls, SWT.CHECK);
		btnWithTime.setLayoutData(new GridData(SWT.CENTER, SWT.CENTER, false, false, 1, 1));
		btnWithTime.setText("Time");
		btnWithTime.setSelection(true);
		
		btnWithThreadId = new Button(mGrpLogControls, SWT.CHECK);
		btnWithThreadId.setLayoutData(new GridData(SWT.CENTER, SWT.CENTER, false, false, 1, 1));
		btnWithThreadId.setText("ThreadId");
		btnWithThreadId.setSelection(true);
		
		Button btnClear = new Button(mGrpLogControls, SWT.NONE);
		btnClear.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				txtLog.setText("");
			}
		});
		btnClear.setLayoutData(new GridData(SWT.RIGHT, SWT.CENTER, false, false, 1, 1));
		btnClear.setText("Clear");
	}

	protected void createDemoControls() {
		// TODO Auto-generated method stub
		
	}

	@Override
	protected void checkSubclass() {
		// Disable the check that prevents subclassing of SWT components
	}

	class AsyncLogHandle implements Runnable {
		final String strInfo;
		final Thread callThread;
		final String mStrTime;
		AsyncLogHandle(String strInfo, Thread callThread, String strTime){
			this.strInfo = strInfo;
			this.callThread = callThread;
			this.mStrTime = strTime;
		}
		public void run() {
			String strCheck = strInfo;
			if (btnWithTime.getSelection()) {
				strCheck = mStrTime + strCheck;
			}
			if (btnWithThreadId.getSelection()) {
				strCheck = "[" + callThread.getName() + "]" + strCheck;
			}
			txtLog.append(strCheck + "\n");
		}
	}
	SimpleDateFormat mDateFormat = new SimpleDateFormat("[HH:mm:ss]");
	protected void log(final String string) {
		mDisplay.asyncExec(new AsyncLogHandle(string, Thread.currentThread(), mDateFormat.format(new Date())));
	}
	
	public String getTabText() {
		return "<Unknown>";
	}

	@Override
	public void dispose() {
		super.dispose();
		System.out.println(this.toString() + " dispose");
	}

	
}
